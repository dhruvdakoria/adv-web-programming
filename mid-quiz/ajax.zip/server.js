const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

app.get('/', function(req, res)
{
  res.sendFile(__dirname + "/form.html")
});

function getRandom(min, max) {
  return Math.floor(Math.random() * (max-min+1)) + min;
}

app.get('/positions', function(req, res)
{

  positions = [];
  for (i = 0; i < 10; i++)
  {
  	positions[i] = {lat: getRandom(0, 90), lng: getRandom(0,90) } 
  }

  res.json(positions);

});


app.listen(port, () => console.log(`Example app listening on port ${port}!`));
