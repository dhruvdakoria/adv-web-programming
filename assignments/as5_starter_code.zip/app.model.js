var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("realtors.db");

// select all the realtors, call the callback with them as a parameter
function getAllRealtors(callback)
{
  db.all("SELECT rowid, * FROM Realtors",
         function(err,results) { callback(results); });
}

// delete a realtor with a given id
function deleteRealtor(id,callback)
{
  db.run("DELETE FROM Realtors WHERE rowid=?", id,
         function(err) { callback(); });
}

// insert an realtor into the table
function addRealtor(realtor,callback)
{
  db.run("INSERT INTO Realtors VALUES (?,?,?)",
         [realtor.firstname, realtor.lastname, realtor.specialties],
         function(err) { callback(); });
}

// update an realtor with a given id
function updateRealtor(realtor,id,callback)
{
  db.run("UPDATE Realtors SET firstname=?,lastname=?,specialties=? WHERE rowid=?",
         [realtor.firstname, realtor.lastname, realtor.specialties, id],
         function(err) { callback(); });
}

// export the functions we have defined
module.exports = {getAllRealtors, deleteRealtor, addRealtor, updateRealtor};
