// include express
const express = require('express');
const app = express();

// include the mustache template engine for express
const mustacheExpress = require('mustache-express');

// include the model so the controller can use its functions
const Model = require('./app.model.js')

// registers the mustache engine with express
app.engine("mustache", mustacheExpress());

// sets mustache to be the view engine
app.set('view engine', 'mustache');

// sets /views to be the /views folder
// files should have the extension filename.mustache
app.set('views', __dirname + '/views');

// ************************* CONTROLLER ACTIONS ****************************

// delete a realtor action (given an id parameter)
app.get('/delete/:id', function(req,res) {

  // 3. render the page with the realtor data
  function renderPage(realtorArray) {
    res.render('main_page', { realtors: realtorArray});
  }

  // 2. Get all the realtors, then render the page
  function getRealtors() { Model.getAllRealtors(renderPage); }

  // 1. delete the realtor first, then get all the realtors
  Model.deleteRealtor(req.params.id, getRealtors);

});

// addform action puts the add realtor form on the page
app.get('/addform', function(req,res) {

  // 2. render the page with the realtor data AND display the add form
  function renderPage(realtorArray)
  {
    res.render('main_page', {addrealtor: true, realtors: realtorArray});
  }

  // 1. get all the realtors, then render the page
  Model.getAllRealtors(renderPage);

});

// addrealtor action handles add form submit, inserts new realtor into table
app.get('/addrealtor', function(req,res) {

  // 3. render the page with the realtor data
  function renderPage(realtorArray) {
    res.render('main_page', { realtors: realtorArray});
  }

  // 2. Get all the realtors, then render the page
  function getRealtors() { Model.getAllRealtors(renderPage); }

  // 1. Insert realtor into table using form data, then get all the realtors
  Model.addRealtor(req.query, getRealtors);

});

// updateform action puts the update realtor form on the page
app.get('/updateform/:id', function(req,res) {

  // 2. render the page with the realtor data AND display update form
  function renderPage(realtorArray)
  {
    // filter the realtorArray for the realtor with the id parameter, that's
    // the realtor that we want to populate the form with (see: formdata)
    res.render('main_page',
      {updaterealtor: true
      ,updateid: req.params.id
      ,formdata : realtorArray.filter(x => (x.rowid == req.params.id))[0]
      ,realtors: realtorArray
      });
  }

  // 1. get all the realtors, then render the page
  Model.getAllRealtors(renderPage);

});

// updaterealtor action handles updating the realtor in the database
app.get('/updaterealtor/:id', function(req,res) {

  // 3. render the page with the realtor data
  function renderPage(realtorArray) {
    res.render('main_page', { realtors: realtorArray});
  }

  // 2. Get all the realtors, then render the page
  function getRealtors() { Model.getAllRealtors(renderPage); }

  // 1. update the realtor in the database, then get all the realtors
  Model.updateRealtor(req.query, req.params.id, getRealtors);

});

// default action: render the page with realtor data
app.get('/', function(req,res) {

  // 2. render the page with the realtor data
  function renderPage(realtorArray) {
    res.render('main_page', { realtors: realtorArray});
  }

  // 1. get all the realtors, then render the page
  Model.getAllRealtors(renderPage);

});

// catch-all router case intended for static files
app.get(/^(.+)$/, function(req,res) {
  res.sendFile(__dirname + req.params[0]);
});

app.listen(8081, function() { console.log("server listening..."); } );
