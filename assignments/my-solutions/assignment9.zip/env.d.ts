declare module "@env" {
    export const GOOGLE_MAPS_API_KEY: string;
}