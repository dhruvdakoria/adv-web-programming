# React-Native-Uber-Clone

This React Native App was built with Expo. The app is attempt to clone the Uber App.

Some features-

- Uses the Google Maps API to display map on the Screen
- Location Autocomplete API for location suggestions as the user will start typing.
- Distance API to calculate distance between 2 places and based on that calculate the cost for different ride offering

You can find the prototype of the app QR Code hosted on expo link <a href="https://expo.dev/@dhruvdakoria/uber-app">HERE</a>
