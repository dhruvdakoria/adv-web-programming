const axios = require('axios');

async function test()
{
  try {
	  
	// make a post request to our server, insert 3 new items
    const response1 = await axios.post('http://localhost:3000/api',
    {
        "address": "15 Lakeview Ave",
        "postal_code": "M4V 3Y4",
        "city": "Toronto",
        "community": "Summerhill",
        "province": "Ontario",
        "price": 1234567,
        "bedrooms": 4,
        "bathrooms": 3,
        "img": "15lakeview.jpeg",
        "description": "Fabulous home and property in sought after Summerhill neighborhood. Superb location on a quiet cul de sac just a short walk to downtown Toronto's shops, restaurants and amenities."
    });
	// response body is JSON object .data
	console.log(response1.data);

    const response2 = await axios.post('http://localhost:3000/api',
	{
        "address": "180 Queen St E",
        "postal_code": "6U6 3Y5",
        "city": "Toronto",
        "community": "Queensway",
        "province": "Ontario",
        "price": 7839758,
        "bedrooms": 5,
        "bathrooms": 4,
        "img": "180queen.jpeg",
        "description": "Fabulous home and property in sought after Queensway neighborhood. Superb location on a quiet cul de sac just a short walk to downtown Toronto's shops, restaurants and amenities."
    });
	console.log(response2.data);

    const response3 = await axios.post('http://localhost:3000/api',
	{
        "address": "229 South St, Unit 1028",
        "postal_code": "5M2 3Y5",
        "city": "London",
        "community": "Southway",
        "province": "Ontario",
        "price": 236479,
        "bedrooms": 4,
        "bathrooms": 3,
        "img": "229south.jpeg",
        "description": "Fabulous home and property in sought after Southway neighborhood. Superb location on a quiet cul de sac just a short walk to downtown London's shops, restaurants and amenities."
    });
	console.log(response3.data);

 
    // Delete item 2,4 from the properties collection
    const response4 = await axios.delete('http://localhost:3000/api/2');
	console.log(response4.data);

    const response5 = await axios.delete('http://localhost:3000/api/4');
	console.log(response5.data);

    // Update item 7 price and description using PUT operation
    const response6 = await axios.put('http://localhost:3000/api/7',
    {
        "address": "180 Queen St E",
        "postal_code": "6U6 3Y5",
        "city": "Toronto",
        "community": "Queensway",
        "province": "Ontario",
        "price": 5555555,
        "bedrooms": 5,
        "bathrooms": 4,
        "img": "180queen.jpeg",
        "description": "Completely renovated home and property in sought after Queensway neighborhood. Superb location on a quiet cul de sac just a short walk to downtown Toronto's shops, restaurants and amenities."
    });
    console.log(response6.data);

    // Get all items from the properties collection
    const response7 = await axios.get('http://localhost:3000/api');
	console.log(response7.data);
	
	
  } catch (error) {
    console.error(error);
  }	
}

// call our test function
test();