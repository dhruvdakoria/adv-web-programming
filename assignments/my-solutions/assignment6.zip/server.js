var express = require('express');
var app = express();
var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("properties.db");

// use JSON middleware to parse request bodies and put result into req.body
app.use(express.json());

// GET the entire properties collection, send it back as JSON data
app.get("/api",
  function(req,res)
  {
    console.log("GET REQUEST RECEIVED");

  	db.all("SELECT rowid as id, address, postal_code, city, community, province, price, bedrooms, bathrooms, img, description FROM Properties",
  		   function(err, results)
  		   {
             // send debug info to console
             console.log(JSON.stringify(results));

             // send back table data as JSON data
             res.json(results);
  		   });
  }
);

// GET the particular id's data, send it back as JSON data
app.get("/api/:id",
  function(req,res)
  {
    console.log("GET REQUEST RECEIVED");
  	db.all("SELECT rowid as id, address, postal_code, city, community, province, price, bedrooms, bathrooms, img, description FROM Properties WHERE rowid=(?)",req.params.id,
  		   function(err, results)
  		   {
             // send debug info to console
             console.log(JSON.stringify(results));

             // send back table data as JSON data
             res.json(results);
  		   });
  }
);

// PUT request to replace the entire collection
app.put("/api",
  function(req,res)
  {
  	console.log("PUT REQUEST REPLACING ENTIRE COLLECTION RECEIVED");

    // make the update to the database
    db.serialize(function() {
        db.run("DELETE FROM Properties",
           function()
           {
            for(let i=0; i<req.body.length; i++){
                db.all("INSERT INTO Properties VALUES (?,?,?,?,?,?,?,?,?,?)",[req.body[i].address, req.body[i].postal_code, req.body[i].city, req.body[i].community, req.body[i].province, req.body[i].price, req.body[i].bedrooms, req.body[i].bathrooms, req.body[i].img, req.body[i].description],
                    function(){
                        if(i==req.body.length-1){
                            res.json({response: "COLLECTION UPDATED"});
                        }
                    }
                );
            }
           }
        );
    });
});

// PUT request to change a specific item in the collection
app.put("/api/:id",
  function(req,res)
  {
  	console.log("PUT REQUEST RECEIVED");

    // make the update to the database
    db.serialize(function() {
        var stmt = db.prepare("UPDATE Properties set address=(?), postal_code=(?), city=(?), community=(?), province=(?), price=(?), bedrooms=(?), bathrooms=(?), img=(?), description=(?) WHERE rowid=(?)");
        stmt.run(req.body.address,req.body.postal_code,req.body.city,req.body.community,req.body.province,req.body.price,req.body.bedrooms,req.body.bathrooms,req.body.img,req.body.description,req.params.id,
               // only send the response when we know the I/O has completed
               function()
               {
                 res.json({response: "ITEM UPDATED"});
               }
        );

      stmt.finalize();
    });
});

// DELETE the entire collection
app.delete("/api",
  function(req,res)
  {
  	console.log("DELETE REQUEST RECEIVED");

    db.run("DELETE FROM Properties",
           function()
           {
             res.json({response: "COLLECTION DELETED"});
           });
  }
);

// DELETE a particular item with specified id
app.delete("/api/:id",
  function(req,res)
  {
  	console.log("DELETE ITEM REQUEST RECEIVED");

    db.run("DELETE FROM Properties WHERE rowid=(?)",req.params.id,
           function()
           {
             res.json({response: "ITEM DELETED"});
           });
  }
);

// POST request to insert a new item to the collection
app.post("/api",
  function(req,res)
  {
  	console.log("POST REQUEST TO INSERT NEW ITEM TO COLLECTION");

    // make the insert to the database
    db.serialize(function() {
        db.all("INSERT INTO Properties VALUES (?,?,?,?,?,?,?,?,?,?)",[req.body.address, req.body.postal_code, req.body.city, req.body.community, req.body.province, req.body.price, req.body.bedrooms, req.body.bathrooms, req.body.img, req.body.description],
            function(){
                res.json({response: "ITEM INSERTED"});
            }
        );
    });
});


var server = app.listen(3000, function(){
  console.log("RESTful API listening on port 3000!")
});
