import logo from './logo.svg';
import './App.css';
import React from 'react';
import {Link, NavLink, Routes, Route} from 'react-router-dom';

class About extends React.Component 
{
  render()
  {
    return <p>Some about page content!</p>;
  }
}

class Home extends React.Component 
{
  render()
  {
    return <p>Some Home page content!</p>;
  }
}

class Contact extends React.Component 
{
  render()
  {
    return <p>Some contact page content!</p>; 
  }
}


class Todo extends React.Component 
{
  constructor(props)
  {
    super(props);

    this.state = {
      isEdit: false,
      editItemId: -1,
      input: "",
      submitted: "",
      todo: [{id:1, text: "Walk the dog"},
            {id:2, text: "Pick up laundry"},
            {id:3, text: "Finish 4WP3 Assignment 8"}]
    }
  }

  handleChange(event)
  {
    this.setState({input: event.target.value });
  }

  handleSubmit()
  {
    this.setState({
      submitted: this.state.input,
      input: "",
      todo: [...this.state.todo, {id: this.state.todo.length + 1, text: this.state.input}]
    });
  }

  handleEdit()
  {
    for(let i = 0; i < this.state.todo.length; i++){
      if(this.state.todo[i].id === this.state.editItemId){
        this.state.todo[i].text = this.state.input;
      }
    }

    this.setState({
      submitted: this.state.input,
      input: "",
      isEdit: false,
      todo: this.state.todo
    });
  }

  deleteItem(todo)
  {
    
    this.setState({
      input: "",
      todo: this.state.todo.filter(t => t !== todo)
    });
  }


  editItem(text, key) {
    //console.log("items:"+this.state.task);
    const items = this.state.todo;

    this.setState({
      todo: items.filter(item => item.key !== key),
      input: text,
      editItemId: key,
      isEdit: true
    });
  }



  render()
  {
    return (
      <div>
        <h1>TODO List</h1>
        <div>
          <input id="" type="text" value={this.state.input} 
                onChange={this.handleChange.bind(this)}
                />
          {(this.state.isEdit) ? <button onClick={this.handleEdit.bind(this)}>
              Edit
            </button> : <button onClick={this.handleSubmit.bind(this)}>
              Add
            </button>}
           <br />
          {/* <p>Added: {this.state.submitted}</p> */}
        </div>
        <div>
          <ul>
          {this.state.todo.map((todo,index) => 
            /* console.log(id, text) */
            <li key={index}>{todo.text}  <button onClick={this.deleteItem.bind(this,todo)}>Delete</button>   <button onClick={this.editItem.bind(this,todo.text,todo.id)}>Edit</button></li>
            )}
          </ul>
        </div>
      </div>
    )
  }
}

class App extends React.Component {

  render()
  {
    return (
      <div>
        <h1>React Router Demo</h1>

        <ul>
          <li><NavLink to="/home">Home</NavLink></li>
          <li><NavLink to="/todo">TODO</NavLink></li>
          <li><NavLink to="/contact">Contact</NavLink></li>
          <li><NavLink to="/about">About</NavLink></li>
        </ul>

        <Routes>
          <Route path="home" element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="todo" element={<Todo />} />
          <Route path="contact" element={<Contact />} />
        </Routes>

      </div>
    )
  }

}


export default App;
