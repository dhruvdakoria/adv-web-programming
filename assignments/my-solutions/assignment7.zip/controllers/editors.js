const express = require('express');
const UsersModel = require('../models/users.js');
const ArticlesModel = require('../models/articles.js')
var router = express.Router()

// Display the editors page
router.get("/", async function(req, res)
{
  allUsers = await UsersModel.getAllUsers();
  allArticles = await ArticlesModel.getAllArticlesWithoutContent();
  req.TPL.allusers = allUsers;
  req.TPL.allarticles = allArticles;
  res.render("editors", req.TPL);
});

// delete user action (given an username parameter)
router.get('/user/delete/:username', function(req,res) {
  UsersModel.deleteUser(req.params.username);
  ArticlesModel.deleteAllArticleByAuthor(req.params.username);
  res.redirect('/editors');
});

// delete article action (given an author,title parameter)
router.get('/article/delete/:author/:title', function(req,res) {
  ArticlesModel.deleteArticle(req.params.author,req.params.title);
  res.redirect('/editors');
});

module.exports = router;
