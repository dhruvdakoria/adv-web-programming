const express = require('express');
var router = express.Router()
const ArticlesModel = require('../models/articles.js')
const UsersModel = require('../models/users.js')

// Displays the login page
router.get("/", async function(req, res)
{
  // if we had an error during form submit, display it, clear it from session
  req.TPL.login_error = req.session.login_error;
  req.session.login_error = "";

  // render the login page
  res.render("login", req.TPL);
});

// Attempts to login a user
// - The action for the form submit on the login page.
router.post("/attemptlogin", async function(req, res)
{

  let validation = await UsersModel.validateLoginAttempt(req.body.username,req.body.password);
  // is the username and password OK?
  if (validation.length != 0)
  {
    // set a session key username  to login the user and their access level
    req.session.username = req.body.username;
    req.session.accesslevel = validation[0].level;

    // re-direct the logged-in user to the members page
    if(validation[0].level=='member'){
      res.redirect("/members");
    }else if(validation[0].level=='editor'){
      res.redirect("/editors");
    }
  }
  else
  {
    // if we have an error, reload the login page with an error
    req.session.login_error = "Invalid username and/or password!";
    res.redirect("/login");
  }

});

// Logout a user
// - Destroys the session key username that is used to determine if a user
// is logged in, re-directs them to the home page.
router.get("/logout", async function(req, res)
{
  delete(req.session.username);
  delete(req.session.accesslevel);
  res.redirect("/home");
});

module.exports = router;
