const sqlite3 = require("sqlite3").verbose();
const sqlite = require("sqlite");

async function init() {
  try {
    db = await sqlite.open({
      filename: 'database.db',
      driver: sqlite3.Database
    });
  } catch(err) {
      console.error(err);
  }
}

init();

// Return all of the articles
async function getAllArticles()
{
  let results = await db.all("SELECT * FROM Articles");
  return results;
}

// Return all of the articles
async function getAllArticlesWithoutContent()
{
  let results = await db.all("SELECT username,title FROM Articles");
  return results;
}

// Create a new article given a title, content and username
async function createArticle(article,username)
{
  await db.run("INSERT INTO Articles VALUES (?,?,?)",
         [article.title, username, article.content]);
}

// Delete all articles by a given author
async function deleteAllArticleByAuthor(author)
{
  await db.run("DELETE FROM Articles WHERE username=?", author);
}

// Delete an article given an author and title
async function deleteArticle(author,title)
{
  await db.run("DELETE FROM Articles WHERE username=? AND title=?", author,title);
}

module.exports = {getAllArticles,createArticle,getAllArticlesWithoutContent,deleteArticle,deleteAllArticleByAuthor};
