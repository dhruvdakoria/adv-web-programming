const sqlite3 = require("sqlite3").verbose();
const sqlite = require("sqlite");

async function init() {
  try {
    db = await sqlite.open({
      filename: 'database.db',
      driver: sqlite3.Database
    });
  } catch(err) {
      console.error(err);
  }
}

init();

// Validate the login attempt
async function validateLoginAttempt(username,password)
{
  let results = await db.all("SELECT * FROM Users WHERE username = ? AND password = ?",username,password);
  return results;
}

// Create User Account
async function createAccount(username,password)
{
  let results = await db.all("INSERT INTO Users VALUES (?,?,?)", [username, password, 'member']);
  console.log(results);
  return results;
}

// Return all of the users
async function getAllUsers()
{
  let results = await db.all("SELECT * FROM Users");
  return results;
}

// Delete user from database given username
async function deleteUser(username){
    let results = await db.all("DELETE FROM Users WHERE username = ?", username);
}

module.exports = {validateLoginAttempt,createAccount,getAllUsers,deleteUser};