var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("realtors.db");


// select all the realtors, call the callback with them as a parameter
function getAllRealtors(callback)
{
  db.all("SELECT rowid, * FROM Realtors",
         function(err,results) { callback(results); });
}

function getAllRealtorsWithError(queryparam,errors,callback)
{
  db.all("SELECT rowid, * FROM Realtors",
         function(err,results) { callback(queryparam,errors,results); });
}

function getAllRealtorsWithErrorUpdate(queryparam,updateid,errors,callback)
{
  db.all("SELECT rowid, * FROM Realtors",
         function(err,results) { callback(queryparam,updateid,errors,results); });
}

// sort column, call the callback with them as a parameter
function sortColumnAscend(columnName,callback)
{
  let query = "SELECT rowid, * FROM Realtors ORDER BY "+columnName+" ASC";
  db.all(query, function(err,results) { callback(results); });
}

// sort column, call the callback with them as a parameter
function sortColumnDescend(columnName,callback)
{
  let query = "SELECT rowid, * FROM Realtors ORDER BY "+columnName+" DESC";
  db.all(query, function(err,results) { callback(results); });
}

// delete a realtor with a given id
function deleteRealtor(id,callback)
{
  db.run("DELETE FROM Realtors WHERE rowid=?", id,
         function(err) { callback(); });
}

// like a realtor with a given id
function likeRealtor(id,callback)
{
  db.run("UPDATE Realtors SET likes = likes + 1 WHERE rowid=?", id,
         function(err) { callback(); });
}

// layoff a realtor with less than 2 likes
function layoffRealtor(callback)
{
  db.run("DELETE FROM Realtors WHERE likes < 2",
         function(err) { callback(); });
}

// add random realtor with less than 2 likes
function randomRealtor(realtor,callback)
{
  db.run("INSERT INTO Realtors VALUES (?,?,?,?)", [realtor.firstname, realtor.lastname, realtor.specialties, realtor.likes],
         function(err) { callback(); });
}

// insert an realtor into the table
function addRealtor(realtor,callback)
{
  db.run("INSERT INTO Realtors VALUES (?,?,?,?)",
         [realtor.firstname, realtor.lastname, realtor.specialties, realtor.likes],
         function(err) { callback(); });
}

// update an realtor with a given id
function updateRealtor(realtor,id,callback)
{
  db.run("UPDATE Realtors SET firstname=?,lastname=?,specialties=?,likes=? WHERE rowid=?",
         [realtor.firstname, realtor.lastname, realtor.specialties, realtor.likes, id],
         function(err) { callback(); });
}

// export the functions we have defined
module.exports = {getAllRealtors, getAllRealtorsWithErrorUpdate, randomRealtor, layoffRealtor, deleteRealtor, likeRealtor, addRealtor, updateRealtor, sortColumnAscend, sortColumnDescend, getAllRealtorsWithError};
