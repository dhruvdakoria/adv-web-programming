const { PromisedDatabase } = require("promised-sqlite3");

const db = new PromisedDatabase();

async function init() {
  try {
      await db.open("database.db"); 
  } catch(err) {
      console.error(err);
  }
}

init();

// Return all of the articles
async function getAllArticles()
{
  let results = await db.all("SELECT * FROM Articles");
  return results;
}

// Create a new article given a title, content and username
async function createArticle(article,username)
{
  await db.run("INSERT INTO Articles VALUES (?,?,?)",
         [article.title, username, article.content]);
}

module.exports = {getAllArticles
                 ,createArticle};
